---
name: xiaoai-speaker
description: 小爱音箱语音播报。一句话控制小爱音箱，无需编写代码，适合定时提醒、生活助手、家庭传话等场景。
version: 1.0.0
author: zkfan
---

# 🔊 xiaoai-speaker

通过 OpenClaw 一句话控制小爱音箱语音播报。

## ✨ 特点

- 🎯 **零代码** - 无需编写 Python，一句话即可使用
- ⚙️ **配置一次** - 账号信息保存在 OpenClaw 配置中
- ⏰ **定时任务** - 与 OpenClaw cron 无缝集成
- 🏠 **多设备** - 支持选择不同房间的小爱音箱

## 🚀 安装

```bash
# 方式1：从 GitHub 安装
openclaw skill install https://github.com/zkfan/xiaoai-speaker

# 方式2：本地安装（开发时）
openclaw skill install ~/.openclaw/workspace/skills/xiaoai-speaker
```

## ⚙️ 配置

### 首次使用配置

```bash
openclaw xiaoai setup
```

按提示输入：
- 小米账号
- 小米密码  
- 默认设备名（可选，如"客厅"）

### 或手动编辑配置

编辑 `~/.openclaw/config.toml`：

```toml
[xiaoai]
user = "你的小米账号"
pass = "你的小米密码"
device = "客厅"  # 可选，默认设备
```

## 💬 使用

### 基础播报

```bash
# 简单播报
openclaw xiaoai say "该喝水啦"

# 指定设备播报
openclaw xiaoai say --device "卧室" "该睡觉了"
```

### 查看设备

```bash
openclaw xiaoai list
```

### 测试连接

```bash
openclaw xiaoai test
```

## ⏰ 定时任务

### 生活提醒

```bash
# 每小时提醒喝水
openclaw cron add \
  --name "喝水提醒" \
  --schedule "0 * * * *" \
  --command "xiaoai say '工作这么久，起来喝杯水吧'"

# 每天8点早安
openclaw cron add \
  --name "早安" \
  --schedule "0 8 * * *" \
  --command "xiaoai say '早上好！今天也要加油'"

# 晚上10点睡觉提醒
openclaw cron add \
  --name "睡觉提醒" \
  --schedule "0 22 * * *" \
  --command "xiaoai say '已经10点了，早点休息'"
```

### 工作辅助

```bash
# 会议提醒（提前5分钟）
openclaw cron add \
  --name "会议提醒" \
  --schedule "55 9 * * 1-5" \
  --command "xiaoai say '10分钟后有会议，请准备'"

# 下班提醒（周五）
openclaw cron add \
  --name "周五下班" \
  --schedule "0 18 * * 5" \
  --command "xiaoai say '周五下班啦，周末愉快'"
```

### 家庭场景

```bash
# 孩子作业时间
openclaw cron add \
  --name "作业时间" \
  --schedule "0 19 * * 1-5" \
  --command "xiaoai say --device '儿童房' '该写作业了'"

# 全家吃饭提醒
openclaw cron add \
  --name "吃饭提醒" \
  --schedule "0 12,18 * * *" \
  --command "xiaoai say '饭做好了，快来吃'"
```

## 📝 使用技巧

### 消息简洁
小爱播报速度有限，建议消息控制在 **20字以内**。

✅ 好的例子：
- "该喝水了"
- "饭做好了"
- "10分钟后开会"

❌ 避免：
- 长段落
- 复杂句子
- 英文混合（发音不准）

### 设备选择

如果家里有多个小爱音箱：

```bash
# 先查看设备列表
openclaw xiaoai list

# 输出示例：
# 🎵 找到 2 个设备：
# 🔊 bc7e8679-xxxx  客厅的小爱音箱mini
#    a1b2c3d4-xxxx  卧室的小爱音箱

# 然后指定设备名（模糊匹配）
openclaw xiaoai say --device "客厅" "消息"
openclaw xiaoai say --device "卧室" "消息"
```

### 音量控制

当前版本不支持直接调音量，可以通过消息内容暗示：
```bash
openclaw xiaoai say "大声提醒：该起床了！"
```

## ❓ 常见问题

**Q: 提示"请先配置账号"？**
A: 运行 `openclaw xiaoai setup` 完成配置。

**Q: 登录失败？**
A: 检查小米账号密码是否正确，账号需要绑定小爱音箱。

**Q: 找不到设备？**
A: 运行 `openclaw xiaoai list` 查看账号下的设备，确认小爱音箱已绑定。

**Q: 定时任务没执行？**
A: 检查 OpenClaw gateway 是否运行：`openclaw gateway status`

**Q: 可以播放音乐吗？**
A: 当前版本只支持文字转语音（TTS），不支持播放音乐。

## 🔧 技术说明

- 底层使用小米云服务 API
- 无需与小爱音箱在同一局域网
- 支持远程控制（任何地方都能发送语音）
- 账号信息本地存储，不上传到第三方

## 📄 开源

GitHub: https://github.com/zkfan/xiaoai-speaker

欢迎 Star 和 PR！
