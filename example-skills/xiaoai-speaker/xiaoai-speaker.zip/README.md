# 🔊 xiaoai-speaker

> 一句话让小爱音箱说话，远程控制、定时提醒，把智能音箱变成你的私人助理

[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![OpenClaw](https://img.shields.io/badge/OpenClaw-Skill-green.svg)](https://openclaw.ai)

## 😫 你是不是也遇到过这些烦恼？

- 手机静音错过重要提醒
- 想远程叫家人吃饭但电话没人接
- 老人/孩子总是忘记按时吃药
- 量化交易信号来了，手机推送被淹没

**小爱音箱明明就在家里，为什么不能直接让它喊出来？**

## ✨ 现在可以了！

```bash
# 一句话，小爱帮你播报
xiaoai say "饭做好了，快来吃！"

# 不在家也能远程喊话
xiaoai say --device "儿童房" "该写作业了"

# 设置定时提醒
openclaw cron add --name "喝水" --schedule "0 * * * *" \
  --command "xiaoai say '该喝水了'"
```

## 🚀 3 分钟快速开始

### 方式一：OpenClaw 用户（推荐 ⭐）

```bash
# 1. 安装
clawhub install xiaoai-speaker

# 2. 配置账号（只需一次）
xiaoai setup

# 3. 开始使用
xiaoai say "你好小爱"
```

### 方式二：GitHub 安装

```bash
# 1. 克隆仓库
cd ~/.openclaw/skills
git clone https://github.com/zkfan/xiaoai-speaker.git

# 2. 添加别名到 .zshrc
echo 'xiaoai() { python3 ~/.openclaw/skills/xiaoai-speaker/main.py "$@"; }' >> ~/.zshrc
source ~/.zshrc

# 3. 配置使用
xiaoai setup
```

### 方式三：Python 开发者

```bash
# 1. 安装依赖
pip install -r requirements.txt

# 2. 配置环境变量
export MI_USER="小米账号"
export MI_PASS="小米密码"

# 3. 运行
python3 scripts/speak.py "你好小爱"
```

## 🎯 核心功能

| 功能 | 命令 | 场景 |
|------|------|------|
| **语音播报** | `xiaoai say "消息"` | 远程喊话、提醒 |
| **多设备** | `xiaoai say -d "客厅"` | 选择特定房间 |
| **定时任务** | `openclaw cron add ...` | 自动提醒 |
| **HTTP API** | `curl ...` | 系统集成 |

## 💡 实用场景示例

### 🏠 生活提醒
```bash
# 每天8点早安
openclaw cron add --name "早安" --schedule "0 8 * * *" \
  --command "xiaoai say '早上好！今天也要加油💪'"

# 每小时喝水提醒
openclaw cron add --name "喝水" --schedule "0 * * * *" \
  --command "xiaoai say '工作这么久，起来喝杯水吧🥤'"

# 睡觉提醒
openclaw cron add --name "睡觉" --schedule "0 22 * * *" \
  --command "xiaoai say '已经10点了，早点休息😴'"
```

### 👨‍👩‍👧‍👦 家庭传话
```bash
# 叫全家吃饭
xiaoai say "饭做好了，快来吃🍚"

# 提醒孩子写作业
xiaoai say -d "儿童房" "该写作业了，写完才能玩📚"

# 提醒老人吃药
xiaoai say "该吃降压药了，记得按时服用💊"
```

### 💼 工作辅助
```bash
# 会议提醒
xiaoai say "10分钟后有会议，请准备📅"

# 任务完成通知
xiaoai say "代码部署完成✅"

# 周五下班
openclaw cron add --name "周五" --schedule "0 18 * * 5" \
  --command "xiaoai say '周五下班啦，周末愉快🎉'"
```

## 📱 效果演示

![痛点对比](./images/01_comparison.png)
*传统方式 vs 代码控制*

![使用场景](./images/03_scenarios.png)
*三大使用场景：生活提醒、家庭传话、效率助手*

## 📖 详细文档

- [OpenClaw 集成指南](./SKILL.md) - OpenClaw 用户使用
- [GitHub 安装指南](./INSTALL_VIA_GITHUB.md) - 手动安装说明
- [使用示例](./examples/) - 代码示例

## 🔧 配置说明

### 环境变量

| 变量名 | 必需 | 说明 |
|--------|------|------|
| `MI_USER` | ✅ | 小米账号 |
| `MI_PASS` | ✅ | 小米密码 |
| `MI_DEVICE_NAME` | ❌ | 默认设备名称 |

### 查看设备列表

```bash
xiaoai list
```

输出示例：
```
🎵 找到 2 个设备：

设备ID                 设备名称             
----------------------------------------------
🔊 bc7e8679-xxxx     客厅的小爱音箱mini    
   a1b2c3d4-xxxx     卧室的小爱音箱        
```

## 🤝 贡献指南

欢迎贡献！你可以：

- 🐛 [提交 Bug](https://github.com/zkfan/xiaoai-speaker/issues)
- 💡 [提出新功能建议](https://github.com/zkfan/xiaoai-speaker/issues)
- 🔧 [提交 Pull Request](https://github.com/zkfan/xiaoai-speaker/pulls)
- ⭐ [给个 Star](https://github.com/zkfan/xiaoai-speaker)

## 📝 相关项目

- [MiService](https://github.com/Yonsm/MiService) - 小米服务 API
- [OpenClaw](https://openclaw.ai) - AI 助手自动化平台

## 📄 License

[MIT License](./LICENSE) © 2026 zkfan

---

> 💡 **提示**：如果这个项目帮到了你，请给个 ⭐ Star 支持一下！

> 📧 **问题反馈**：[GitHub Issues](https://github.com/zkfan/xiaoai-speaker/issues)
