#!/usr/bin/env python3
"""
OpenClaw xiaoai-speaker 集成脚本
通过 OpenClaw 配置简化使用
"""

import os
import sys
import json

CONFIG_FILE = os.path.expanduser("~/.openclaw/xiaoai_config.json")

def load_config():
    """加载配置"""
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE) as f:
            return json.load(f)
    return {}

def save_config(config):
    """保存配置"""
    os.makedirs(os.path.dirname(CONFIG_FILE), exist_ok=True)
    with open(CONFIG_FILE, 'w') as f:
        json.dump(config, f, indent=2)

def setup():
    """交互式配置"""
    print("🎙️  小爱音箱语音播报配置")
    print("=" * 40)
    
    config = load_config()
    
    user = input(f"小米账号 [{config.get('user', '')}]: ").strip()
    if user:
        config['user'] = user
    
    import getpass
    passwd = getpass.getpass("小米密码: ").strip()
    if passwd:
        config['pass'] = passwd
    
    device = input("默认设备名（如'客厅'，可选）[{}]: ".format(config.get('device', ''))).strip()
    if device:
        config['device'] = device
    
    save_config(config)
    print("\n✅ 配置已保存！")
    print(f"配置文件: {CONFIG_FILE}")

def say(message, device=None):
    """播报消息"""
    config = load_config()
    
    if not config.get('user') or not config.get('pass'):
        print("❌ 请先运行: python xiaoai_cli.py setup")
        return 1
    
    # 设置环境变量
    os.environ['MI_USER'] = config['user']
    os.environ['MI_PASS'] = config['pass']
    
    if device:
        os.environ['MI_DEVICE_NAME'] = device
    elif config.get('device'):
        os.environ['MI_DEVICE_NAME'] = config['device']
    
    # 调用原脚本
    import subprocess
    script_path = os.path.join(os.path.dirname(__file__), 'scripts', 'speak.py')
    result = subprocess.run([sys.executable, script_path, message])
    return result.returncode

def list_devices():
    """列出设备"""
    config = load_config()
    
    if not config.get('user') or not config.get('pass'):
        print("❌ 请先运行: python xiaoai_cli.py setup")
        return 1
    
    os.environ['MI_USER'] = config['user']
    os.environ['MI_PASS'] = config['pass']
    
    import subprocess
    script_path = os.path.join(os.path.dirname(__file__), 'scripts', 'list.py')
    result = subprocess.run([sys.executable, script_path])
    return result.returncode

def test():
    """测试连接"""
    config = load_config()
    
    if not config.get('user') or not config.get('pass'):
        print("❌ 请先运行配置")
        print("   openclaw xiaoai setup")
        return 1
    
    print("🧪 测试连接...")
    os.environ['MI_USER'] = config['user']
    os.environ['MI_PASS'] = config['pass']
    
    import subprocess
    script_path = os.path.join(os.path.dirname(__file__), 'scripts', 'list.py')
    result = subprocess.run([sys.executable, script_path], capture_output=True, text=True)
    
    if result.returncode == 0 and 'device' in result.stdout.lower():
        print("✅ 连接成功！")
        return 0
    else:
        print("❌ 连接失败，请检查账号密码")
        return 1

def show_help():
    """显示帮助"""
    print("🔊 xiaoai-speaker - 小爱音箱语音播报")
    print()
    print("用法:")
    print("  openclaw xiaoai setup                # 配置小米账号")
    print("  openclaw xiaoai test                 # 测试连接")
    print("  openclaw xiaoai list                 # 查看设备列表")
    print("  openclaw xiaoai say '消息'           # 播报消息")
    print("  openclaw xiaoai say '消息' --device '客厅'  # 指定设备")
    print()
    print("示例:")
    print("  openclaw xiaoai say '该喝水啦'")
    print("  openclaw xiaoai say '饭做好了' --device '厨房'")
    print()
    print("定时任务:")
    print("  openclaw cron add --name '喝水提醒' --schedule '0 * * * *' --command 'xiaoai say 该喝水了'")

def main():
    if len(sys.argv) < 2:
        show_help()
        return 0
    
    command = sys.argv[1]
    
    if command in ['help', '-h', '--help']:
        show_help()
        return 0
    elif command == 'setup':
        return setup()
    elif command == 'test':
        return test()
    elif command == 'say':
        if len(sys.argv) < 3:
            print("❌ 请提供消息内容")
            print("   示例: openclaw xiaoai say '该喝水啦'")
            return 1
        message = sys.argv[2]
        device = None
        # 支持 --device 或 -d
        for i, arg in enumerate(sys.argv):
            if arg in ['--device', '-d'] and i + 1 < len(sys.argv):
                device = sys.argv[i + 1]
                break
        return say(message, device)
    elif command == 'list':
        return list_devices()
    else:
        print(f"❌ 未知命令: {command}")
        print("   运行 'openclaw xiaoai help' 查看帮助")
        return 1

if __name__ == '__main__':
    sys.exit(main())
